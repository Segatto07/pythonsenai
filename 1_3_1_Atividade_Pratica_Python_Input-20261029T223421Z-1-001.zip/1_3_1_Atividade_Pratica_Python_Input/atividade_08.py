#(def) vem de “define/ir” ela serve para criar uma função, que é um bloco de código com um nome, que você pode usar quantas vezes quiser.
#(if) vem de “if/condicional” ela serve para criar uma condição, que é um bloco de código que só será executado se a condição for verdadeira.
#(raise) vem de “raise/levantar” ela serve para levantar uma exceção, que é um erro que interrompe a execução do programa.
#(main) vem de “main/principal” ela serve para indicar que o código dentro do bloco main só será executado se o arquivo for executado diretamente, e não importado como módulo.
#(try) vem de “try/tentar” ela serve para tentar executar um bloco de código, e se ocorrer uma exceção, ela será capturada pelo bloco except.

distancia = float(input("Distância percorrida (km): ").replace(",", "."))
tempo = float(input("Tempo gasto (horas): ").replace(",", "."))

velocidade = distancia / tempo

print("A velocidade média é de", distancia / tempo, "km/h.", velocidade)



