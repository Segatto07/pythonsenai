G = 6.67e-11
m1 = float(input("Digite a massa do primeiro objeto em (kg): ").replace(",", "."))
m2 = float(input("Digite a massa do segundo objeto em (kg): ").replace(",", "."))
r = float(input("Digite a distância entre os objetos em (m): ").replace(",", "."))

F = G * (m1 * m2) / (r ** 2)

print("A força gravitacional é de: ", F, "N")
