num1 = float(input("Digite o primeiro número: ").replace(",", "."))
num2 = float(input("Digite o segundo número: ").replace(",", "." ))

resultado = num1 / num2

print("A divisão de", num1, "por", num2, "é = ", resultado)

