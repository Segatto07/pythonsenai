#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Calculadora Pro
===============

Calculadora com interface gráfica moderna (CustomTkinter), tema escuro/claro,
histórico de operações e suporte completo ao teclado.

O arquivo é dividido em três partes independentes:

1. MOTOR MATEMÁTICO  - tokenizador, parser e avaliador seguros (sem eval()).
2. MODELO            - estado da calculadora e regras de digitação (sem GUI).
3. INTERFACE         - janela, botões, histórico e atalhos (CustomTkinter).

Dependência: customtkinter  ->  pip install customtkinter
Execução:    python calculadora.py
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from decimal import (
    ROUND_HALF_EVEN,
    Context,
    Decimal,
    DivisionByZero,
    InvalidOperation,
    Overflow,
)
from functools import partial
from typing import Optional

try:
    import customtkinter as ctk
except ImportError:  # A mensagem amigável é exibida em main().
    ctk = None


# =============================================================================
# 1. MOTOR MATEMÁTICO (seguro, sem eval)
# =============================================================================
#
# Gramática suportada (da menor para a maior precedência):
#
#   expressao := termo (('+' | '-') termo)*
#   termo     := unario (('*' | '/') unario)*
#   unario    := ('+' | '-') unario | potencia
#   potencia  := sufixo ['^' unario]          (associativa à direita)
#   sufixo    := primario '%'*
#   primario  := NUMERO | '(' expressao ')' | '√' primario
#
# Os cálculos usam Decimal (precisão de 40 dígitos), evitando erros típicos de
# ponto flutuante como 0.1 + 0.2 = 0.30000000000000004.

MAX_EXPRESSION_LENGTH = 120   # tamanho máximo da expressão digitada
MAX_EXPONENT = 100_000        # evita potências que travariam o programa
MAX_HISTORY = 100             # quantidade máxima de itens no histórico

_CALC_CONTEXT = Context(
    prec=40,
    rounding=ROUND_HALF_EVEN,
    Emin=-999_999,
    Emax=999_999,
    traps=[InvalidOperation, DivisionByZero, Overflow],
)
_DISPLAY_CONTEXT = Context(prec=15, rounding=ROUND_HALF_EVEN)


class CalculatorError(Exception):
    """Erro de cálculo com mensagem pronta para ser exibida ao usuário."""


@dataclass(frozen=True)
class Token:
    """Unidade léxica de uma expressão. kind: NUM, OP, LPAREN, RPAREN, PERCENT, SQRT."""

    kind: str
    value: str


_NUMBER_RE = re.compile(r"(?:\d+[.,]?\d*|[.,]\d+)(?:[eE][+-]?\d+)?")
_OPERATOR_ALIASES = {
    "+": "+", "-": "-", "−": "-",
    "*": "*", "×": "*",
    "/": "/", "÷": "/",
    "^": "^",
}


def tokenize(text: str) -> list[Token]:
    """Converte o texto da expressão em uma lista de tokens.

    Aceita vírgula ou ponto como separador decimal e os símbolos × ÷ − √.
    Qualquer outro caractere gera CalculatorError.
    """
    tokens: list[Token] = []
    position = 0
    while position < len(text):
        char = text[position]
        if char.isspace():
            position += 1
            continue

        number = _NUMBER_RE.match(text, position)
        if number:
            tokens.append(Token("NUM", number.group()))
            position = number.end()
            continue

        if char in _OPERATOR_ALIASES:
            tokens.append(Token("OP", _OPERATOR_ALIASES[char]))
        elif char == "(":
            tokens.append(Token("LPAREN", char))
        elif char == ")":
            tokens.append(Token("RPAREN", char))
        elif char == "%":
            tokens.append(Token("PERCENT", char))
        elif char == "√":
            tokens.append(Token("SQRT", char))
        else:
            raise CalculatorError(f"Caractere inválido: '{char}'")
        position += 1
    return tokens


# Nós da árvore sintática (tuplas):
#   ("num", Decimal) | ("neg", nó) | ("pct", nó) | ("sqrt", nó)
#   ("bin", operador, nó_esquerdo, nó_direito)
Node = tuple


class _Parser:
    """Parser descendente recursivo que transforma tokens em uma árvore."""

    def __init__(self, tokens: list[Token]) -> None:
        self._tokens = tokens
        self._position = 0

    # -- utilidades -----------------------------------------------------------
    def _peek(self) -> Optional[Token]:
        if self._position < len(self._tokens):
            return self._tokens[self._position]
        return None

    def _next(self) -> Token:
        token = self._peek()
        if token is None:
            raise CalculatorError("Expressão incompleta")
        self._position += 1
        return token

    def _peek_operator(self, *symbols: str) -> bool:
        token = self._peek()
        return token is not None and token.kind == "OP" and token.value in symbols

    # -- gramática ------------------------------------------------------------
    def parse(self) -> Node:
        if not self._tokens:
            raise CalculatorError("Expressão vazia")
        tree = self._expression()
        if self._peek() is not None:
            raise CalculatorError("Expressão inválida")
        return tree

    def _expression(self) -> Node:
        node = self._term()
        while self._peek_operator("+", "-"):
            operator = self._next().value
            node = ("bin", operator, node, self._term())
        return node

    def _term(self) -> Node:
        node = self._unary()
        while self._peek_operator("*", "/"):
            operator = self._next().value
            node = ("bin", operator, node, self._unary())
        return node

    def _unary(self) -> Node:
        if self._peek_operator("+", "-"):
            operator = self._next().value
            operand = self._unary()
            return ("neg", operand) if operator == "-" else operand
        return self._power()

    def _power(self) -> Node:
        base = self._postfix()
        if self._peek_operator("^"):
            self._next()
            return ("bin", "^", base, self._unary())
        return base

    def _postfix(self) -> Node:
        node = self._primary()
        while self._peek() is not None and self._peek().kind == "PERCENT":
            self._next()
            node = ("pct", node)
        return node

    def _primary(self) -> Node:
        token = self._next()
        if token.kind == "NUM":
            try:
                return ("num", _CALC_CONTEXT.create_decimal(token.value.replace(",", ".")))
            except InvalidOperation:
                raise CalculatorError("Número inválido") from None
        if token.kind == "LPAREN":
            node = self._expression()
            closing = self._peek()
            if closing is None or closing.kind != "RPAREN":
                raise CalculatorError("Parênteses não balanceados")
            self._next()
            return node
        if token.kind == "SQRT":
            return ("sqrt", self._primary())
        raise CalculatorError("Expressão inválida")


def _evaluate_node(node: Node) -> Decimal:
    """Avalia recursivamente a árvore sintática usando aritmética Decimal."""
    ctx = _CALC_CONTEXT
    kind = node[0]

    if kind == "num":
        return node[1]
    if kind == "neg":
        return ctx.minus(_evaluate_node(node[1]))
    if kind == "pct":
        return ctx.divide(_evaluate_node(node[1]), Decimal(100))
    if kind == "sqrt":
        value = _evaluate_node(node[1])
        if value < 0:
            raise CalculatorError("Raiz de número negativo")
        return ctx.sqrt(value)

    # Operações binárias
    _, operator, left_node, right_node = node
    left = _evaluate_node(left_node)

    # Comportamento de calculadora: "200 + 10%" = 200 + (10% de 200) = 220.
    if operator in ("+", "-") and right_node[0] == "pct":
        right = ctx.divide(ctx.multiply(left, _evaluate_node(right_node[1])), Decimal(100))
    else:
        right = _evaluate_node(right_node)

    if operator == "+":
        return ctx.add(left, right)
    if operator == "-":
        return ctx.subtract(left, right)
    if operator == "*":
        return ctx.multiply(left, right)
    if operator == "/":
        if right == 0:
            raise CalculatorError("Divisão por zero")
        return ctx.divide(left, right)
    if operator == "^":
        if abs(right) > MAX_EXPONENT:
            raise CalculatorError("Expoente muito grande")
        if left == 0 and right == 0:
            raise CalculatorError("0^0 é indefinido")
        if left == 0 and right < 0:
            raise CalculatorError("Divisão por zero")
        if left < 0 and right != right.to_integral_value():
            raise CalculatorError("Resultado não é um número real")
        return ctx.power(left, right)

    raise CalculatorError("Operador desconhecido")  # inalcançável


def evaluate_expression(text: str) -> Decimal:
    """Calcula uma expressão matemática de forma segura.

    Levanta CalculatorError (com mensagem em português) para qualquer problema.
    """
    if not text or not text.strip():
        raise CalculatorError("Expressão vazia")
    if len(text) > MAX_EXPRESSION_LENGTH * 2:
        raise CalculatorError("Expressão muito longa")
    try:
        tree = _Parser(tokenize(text)).parse()
        return _evaluate_node(tree)
    except CalculatorError:
        raise
    except Overflow:
        raise CalculatorError("Resultado fora do limite") from None
    except DivisionByZero:
        raise CalculatorError("Divisão por zero") from None
    except InvalidOperation:
        raise CalculatorError("Operação inválida") from None
    except RecursionError:
        raise CalculatorError("Expressão muito complexa") from None


def format_number(value: Decimal) -> str:
    """Formata um Decimal para exibição, usando vírgula como separador decimal.

    - Inteiros (até 25 dígitos) são exibidos exatamente.
    - Não inteiros mostram até 15 dígitos significativos, sem zeros à direita.
    - Números muito grandes ou muito pequenos usam notação científica.
    """
    if value == 0:
        return "0"
    if value == value.to_integral_value() and value.adjusted() <= 24:
        return str(int(value))

    rounded = _DISPLAY_CONTEXT.create_decimal(value).normalize(_DISPLAY_CONTEXT)
    if -9 <= rounded.adjusted() <= 20:
        text = format(rounded, "f")
    else:
        text = format(rounded, "E")
    return text.replace(".", ",")


def auto_close_parentheses(expression: str) -> str:
    """Fecha automaticamente parênteses que o usuário deixou abertos."""
    missing = expression.count("(") - expression.count(")")
    return expression + ")" * missing if missing > 0 else expression


def prettify_expression(expression: str) -> str:
    """Adiciona espaços ao redor dos operadores binários (apenas para exibição)."""
    return re.sub(r"(?<=[\d)%])([+\-×÷^])", r" \1 ", expression)


# =============================================================================
# 2. MODELO (estado e regras de digitação, independente da interface)
# =============================================================================

OPERATORS = "+-×÷^"
_TRAILING_NUMBER = re.compile(r"(?:\d+(?:,\d*)?|,\d+)$")
_NUMBER_FINDER = re.compile(r"\d+(?:,\d*)?")


@dataclass(frozen=True)
class HistoryEntry:
    """Uma operação concluída no histórico."""

    expression: str
    result: str


class CalculatorModel:
    """Guarda a expressão atual, o histórico e aplica as regras de digitação.

    A expressão é mantida como texto, usando os símbolos exibidos ao usuário
    (× ÷ ^ √ %) e vírgula como separador decimal.
    """

    def __init__(self) -> None:
        self.history: list[HistoryEntry] = []
        self.history_version = 0
        self.expression = ""
        self.last_expression = ""
        self.just_evaluated = False
        self.error = ""

    # -- consultas ------------------------------------------------------------
    @property
    def preview(self) -> Optional[str]:
        """Resultado provisório da expressão atual (None se não calculável)."""
        if self.just_evaluated or not self.expression:
            return None
        try:
            value = evaluate_expression(auto_close_parentheses(self.expression))
        except CalculatorError:
            return None
        return format_number(value)

    @property
    def display_result(self) -> str:
        """Texto para a linha grande do display."""
        if self.error:
            return self.error
        if self.just_evaluated:
            return self.expression
        preview = self.preview
        if preview is not None:
            return preview
        numbers = _NUMBER_FINDER.findall(self.expression)
        return numbers[-1] if numbers else "0"

    # -- utilidades internas --------------------------------------------------
    def _begin_input(self, continue_with_result: bool) -> None:
        """Prepara a edição: limpa erro e trata o estado pós-resultado."""
        self.error = ""
        if self.just_evaluated:
            if continue_with_result:
                # Resultado negativo vira "(-5)" para que 5^2 não vire -(5^2).
                if self.expression.startswith("-"):
                    self.expression = f"({self.expression})"
            else:
                self.expression = ""
            self.just_evaluated = False
            self.last_expression = ""

    def _append(self, text: str) -> None:
        if len(self.expression) + len(text) <= MAX_EXPRESSION_LENGTH:
            self.expression += text

    def _ends_with_operand(self) -> bool:
        return bool(self.expression) and (
            self.expression[-1].isdigit() or self.expression[-1] in ")%"
        )

    # -- entradas do usuário --------------------------------------------------
    def press_digit(self, digit: str) -> None:
        self._begin_input(continue_with_result=False)
        if self._ends_with_operand() and not self.expression[-1].isdigit():
            self._append("×")  # multiplicação implícita: (2)3 -> (2)×3
        match = _TRAILING_NUMBER.search(self.expression)
        if match and match.group() == "0":
            self.expression = self.expression[:-1]  # evita "05"
        self._append(digit)

    def press_decimal(self) -> None:
        self._begin_input(continue_with_result=False)
        match = _TRAILING_NUMBER.search(self.expression)
        if match:
            if "," not in match.group():
                self._append(",")
            return
        if self._ends_with_operand():
            self._append("×")
        self._append("0,")

    def press_operator(self, operator: str) -> None:
        self._begin_input(continue_with_result=True)
        if not self.expression:
            if operator == "-":
                self._append("-")  # número negativo no início
            return

        last = self.expression[-1]
        if last in OPERATORS:
            if operator == "-" and last in "×÷^":
                self._append("-")  # sinal negativo após operador: 2×-3
                return
            stripped = self.expression.rstrip(OPERATORS)  # troca o operador
            self.expression = stripped
            if not stripped or stripped[-1] == "(":
                if operator == "-":
                    self._append("-")
                return
        elif last == "(":
            if operator == "-":
                self._append("-")
            return
        self._append(operator)

    def press_percent(self) -> None:
        self._begin_input(continue_with_result=True)
        if self._ends_with_operand():
            self._append("%")

    def press_sqrt(self) -> None:
        if self.just_evaluated and not self.error:
            # Raiz do resultado atual: √(resultado)
            self.expression = f"√({self.expression})"
            self.just_evaluated = False
            self.last_expression = ""
            return
        self._begin_input(continue_with_result=False)
        if self._ends_with_operand():
            self._append("×")
        self._append("√(")

    def press_open(self) -> None:
        self._begin_input(continue_with_result=False)
        if self._ends_with_operand():
            self._append("×")
        self._append("(")

    def press_close(self) -> None:
        if self.just_evaluated:
            return
        self.error = ""
        expression = self.expression
        if (
            expression
            and expression.count("(") > expression.count(")")
            and expression[-1] not in OPERATORS
            and expression[-1] != "("
        ):
            self._append(")")

    def toggle_sign(self) -> None:
        """Inverte o sinal do último número: 5 -> (-5) -> 5."""
        self._begin_input(continue_with_result=True)
        expression = self.expression

        closed = re.search(r"\(-(\d+(?:,\d*)?)\)$", expression)
        if closed:
            self.expression = expression[: closed.start()] + closed.group(1)
            return
        opened = re.search(r"\(-(\d+(?:,\d*)?)$", expression)
        if opened:
            self.expression = expression[: opened.start()] + opened.group(1)
            return
        number = _TRAILING_NUMBER.search(expression)
        if number:
            self.expression = expression[: number.start()] + "(-" + number.group() + ")"
        elif not expression or expression[-1] in OPERATORS or expression[-1] == "(":
            self._append("(-")

    def backspace(self) -> None:
        self.error = ""
        if self.just_evaluated:
            self.just_evaluated = False
            self.last_expression = ""
        if self.expression.endswith("√("):
            self.expression = self.expression[:-2]
        else:
            self.expression = self.expression[:-1]

    def clear(self) -> None:
        self.expression = ""
        self.last_expression = ""
        self.just_evaluated = False
        self.error = ""

    def evaluate(self) -> None:
        """Calcula a expressão, registra no histórico ou define a mensagem de erro."""
        if not self.expression or self.just_evaluated:
            return
        closed_expression = auto_close_parentheses(self.expression)
        try:
            result = format_number(evaluate_expression(closed_expression))
        except CalculatorError as error:
            self.error = str(error)
            return

        if closed_expression != result:
            self.history.append(HistoryEntry(closed_expression, result))
            del self.history[:-MAX_HISTORY]
            self.history_version += 1
        self.last_expression = closed_expression
        self.expression = result
        self.just_evaluated = True
        self.error = ""

    def recall(self, entry: HistoryEntry) -> None:
        """Carrega no display um resultado do histórico."""
        self.error = ""
        self.last_expression = entry.expression
        self.expression = entry.result
        self.just_evaluated = True

    def clear_history(self) -> None:
        self.history.clear()
        self.history_version += 1


# =============================================================================
# 3. INTERFACE GRÁFICA (CustomTkinter)
# =============================================================================

class Palette:
    """Cores no formato (tema claro, tema escuro); o CustomTkinter alterna sozinho."""

    BACKGROUND = ("#EEF0F6", "#14151B")
    PANEL = ("#FFFFFF", "#1E1F27")
    PANEL_ALT = ("#F1F2F8", "#272935")
    PANEL_ALT_HOVER = ("#E2E5F0", "#33364A")
    TEXT = ("#1B1D26", "#F2F3F8")
    MUTED = ("#6B7084", "#8E93A8")
    ERROR = ("#D13B4B", "#FF6B7A")

    BUTTONS = {
        "number": {
            "fg_color": ("#E6E8F0", "#2B2D3A"),
            "hover_color": ("#D5D8E4", "#3A3D4F"),
            "text_color": ("#1B1D26", "#F2F3F8"),
        },
        "function": {
            "fg_color": ("#D5D9E8", "#3A3D4F"),
            "hover_color": ("#C3C8DC", "#4A4E64"),
            "text_color": ("#1B1D26", "#F2F3F8"),
        },
        "operator": {
            "fg_color": ("#DCD3FF", "#3F3769"),
            "hover_color": ("#CBBFFF", "#52488A"),
            "text_color": ("#5A3FD0", "#C9BEFF"),
        },
        "equals": {
            "fg_color": ("#6C4DFF", "#7C5CFF"),
            "hover_color": ("#5A3BEA", "#6A49F0"),
            "text_color": ("#FFFFFF", "#FFFFFF"),
        },
        "clear": {
            "fg_color": ("#FFD9DD", "#4A2830"),
            "hover_color": ("#FFC4CA", "#60303B"),
            "text_color": ("#D13B4B", "#FF6B7A"),
        },
    }


# (rótulo, método do modelo, argumento, estilo)
KEYPAD = (
    (("C", "clear", None, "clear"), ("⌫", "backspace", None, "function"),
     ("(", "press_open", None, "function"), (")", "press_close", None, "function")),
    (("√", "press_sqrt", None, "operator"), ("xʸ", "press_operator", "^", "operator"),
     ("%", "press_percent", None, "operator"), ("÷", "press_operator", "÷", "operator")),
    (("7", "press_digit", "7", "number"), ("8", "press_digit", "8", "number"),
     ("9", "press_digit", "9", "number"), ("×", "press_operator", "×", "operator")),
    (("4", "press_digit", "4", "number"), ("5", "press_digit", "5", "number"),
     ("6", "press_digit", "6", "number"), ("−", "press_operator", "-", "operator")),
    (("1", "press_digit", "1", "number"), ("2", "press_digit", "2", "number"),
     ("3", "press_digit", "3", "number"), ("+", "press_operator", "+", "operator")),
    (("±", "toggle_sign", None, "function"), ("0", "press_digit", "0", "number"),
     (",", "press_decimal", None, "number"), ("=", "evaluate", None, "equals")),
)

# Atalhos de teclado: caractere digitado -> (método do modelo, argumento)
KEY_BINDINGS = {
    **{digit: ("press_digit", digit) for digit in "0123456789"},
    "+": ("press_operator", "+"),
    "-": ("press_operator", "-"),
    "*": ("press_operator", "×"),
    "x": ("press_operator", "×"),
    "/": ("press_operator", "÷"),
    "^": ("press_operator", "^"),
    "%": ("press_percent", None),
    "(": ("press_open", None),
    ")": ("press_close", None),
    ".": ("press_decimal", None),
    ",": ("press_decimal", None),
    "r": ("press_sqrt", None),
    "=": ("evaluate", None),
}

_BaseWindow = ctk.CTk if ctk is not None else object


def _shorten(text: str, limit: int) -> str:
    """Corta o texto pela esquerda, mantendo o final (o mais relevante)."""
    return text if len(text) <= limit else "…" + text[-(limit - 1):]


def _result_font_size(text: str) -> int:
    """Reduz a fonte do resultado conforme o tamanho do texto."""
    length = len(text)
    if length <= 10:
        return 46
    if length <= 13:
        return 38
    if length <= 17:
        return 30
    if length <= 22:
        return 24
    return 20


class CalculatorApp(_BaseWindow):
    """Janela principal da calculadora."""

    def __init__(self) -> None:
        super().__init__()
        self.model = CalculatorModel()
        self._rendered_history_version = -1

        self.title("Calculadora Pro")
        self.geometry("780x640")
        self.minsize(680, 580)
        self.configure(fg_color=Palette.BACKGROUND)

        self.button_font = ctk.CTkFont(size=20, weight="bold")
        self.result_font = ctk.CTkFont(size=46, weight="bold")
        self.expression_font = ctk.CTkFont(size=18)
        self.history_font = ctk.CTkFont(size=13)

        self._build_ui()
        self.bind("<Key>", self._on_key)
        self._refresh()
        self.focus_set()

    # -- construção da interface ---------------------------------------------
    def _build_ui(self) -> None:
        self.grid_columnconfigure(0, weight=3)
        self.grid_columnconfigure(1, weight=2, minsize=260)
        self.grid_rowconfigure(1, weight=1)

        self._build_header()
        self._build_calculator_area()
        self._build_history_panel()

    def _build_header(self) -> None:
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, columnspan=2, sticky="ew", padx=22, pady=(16, 4))
        header.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            header, text="Calculadora",
            font=ctk.CTkFont(size=22, weight="bold"), text_color=Palette.TEXT,
        ).grid(row=0, column=0, sticky="w")

        self.theme_switch = ctk.CTkSwitch(
            header, text="Tema escuro", text_color=Palette.TEXT,
            command=self._toggle_theme,
        )
        self.theme_switch.grid(row=0, column=1, sticky="e")
        self.theme_switch.select()

    def _build_calculator_area(self) -> None:
        area = ctk.CTkFrame(self, fg_color="transparent")
        area.grid(row=1, column=0, sticky="nsew", padx=(22, 10), pady=(6, 22))
        area.grid_columnconfigure(0, weight=1)
        area.grid_rowconfigure(1, weight=1)

        display = ctk.CTkFrame(area, corner_radius=18, fg_color=Palette.PANEL)
        display.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        display.grid_columnconfigure(0, weight=1)

        self.expression_label = ctk.CTkLabel(
            display, text="", anchor="e", height=26,
            font=self.expression_font, text_color=Palette.MUTED,
        )
        self.expression_label.grid(row=0, column=0, sticky="ew", padx=18, pady=(14, 0))

        self.result_label = ctk.CTkLabel(
            display, text="0", anchor="e",
            font=self.result_font, text_color=Palette.TEXT,
        )
        self.result_label.grid(row=1, column=0, sticky="ew", padx=18, pady=(0, 14))

        keypad = ctk.CTkFrame(area, fg_color="transparent")
        keypad.grid(row=1, column=0, sticky="nsew")
        for column in range(4):
            keypad.grid_columnconfigure(column, weight=1, uniform="keys")
        for row_index, row in enumerate(KEYPAD):
            keypad.grid_rowconfigure(row_index, weight=1, uniform="rows")
            for column_index, (label, method, argument, style) in enumerate(row):
                ctk.CTkButton(
                    keypad, text=label, width=64, height=52, corner_radius=14,
                    font=self.button_font,
                    command=partial(self._press, method, argument),
                    **Palette.BUTTONS[style],
                ).grid(row=row_index, column=column_index, sticky="nsew", padx=4, pady=4)

    def _build_history_panel(self) -> None:
        panel = ctk.CTkFrame(self, corner_radius=18, fg_color=Palette.PANEL)
        panel.grid(row=1, column=1, sticky="nsew", padx=(10, 22), pady=(6, 22))
        panel.grid_columnconfigure(0, weight=1)
        panel.grid_rowconfigure(1, weight=1)

        top = ctk.CTkFrame(panel, fg_color="transparent")
        top.grid(row=0, column=0, sticky="ew", padx=14, pady=(12, 4))
        top.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(
            top, text="Histórico",
            font=ctk.CTkFont(size=16, weight="bold"), text_color=Palette.TEXT,
        ).grid(row=0, column=0, sticky="w")

        ctk.CTkButton(
            top, text="Limpar", width=72, height=28, corner_radius=10,
            font=ctk.CTkFont(size=13), command=self._clear_history,
            **Palette.BUTTONS["clear"],
        ).grid(row=0, column=1, sticky="e")

        self.history_list = ctk.CTkScrollableFrame(panel, fg_color="transparent")
        self.history_list.grid(row=1, column=0, sticky="nsew", padx=8, pady=(0, 10))

    # -- ações ----------------------------------------------------------------
    def _press(self, method_name: str, argument: Optional[str] = None) -> None:
        """Executa uma ação do modelo e atualiza a tela."""
        method = getattr(self.model, method_name)
        if argument is None:
            method()
        else:
            method(argument)
        self._refresh()

    def _on_key(self, event) -> None:
        """Mapeia o teclado físico para as ações da calculadora."""
        if event.keysym in ("Return", "KP_Enter"):
            self._press("evaluate")
        elif event.keysym == "BackSpace":
            self._press("backspace")
        elif event.keysym in ("Escape", "Delete"):
            self._press("clear")
        elif event.char:
            binding = KEY_BINDINGS.get(event.char.lower())
            if binding:
                self._press(*binding)

    def _toggle_theme(self) -> None:
        dark = bool(self.theme_switch.get())
        ctk.set_appearance_mode("dark" if dark else "light")
        self.theme_switch.configure(text="Tema escuro" if dark else "Tema claro")
        self.focus_set()

    def _clear_history(self) -> None:
        self.model.clear_history()
        self._refresh()
        self.focus_set()

    def _use_history_entry(self, entry: HistoryEntry) -> None:
        self.model.recall(entry)
        self._refresh()
        self.focus_set()

    # -- atualização da tela ---------------------------------------------------
    def _refresh(self) -> None:
        model = self.model

        if model.just_evaluated:
            top_text = f"{prettify_expression(model.last_expression)} ="
        else:
            top_text = prettify_expression(model.expression)
        self.expression_label.configure(text=_shorten(top_text, 44))

        result_text = model.display_result
        if model.error:
            self.result_font.configure(size=24)
            self.result_label.configure(text=result_text, text_color=Palette.ERROR)
        else:
            result_text = _shorten(result_text, 28)
            self.result_font.configure(size=_result_font_size(result_text))
            self.result_label.configure(text=result_text, text_color=Palette.TEXT)

        if model.history_version != self._rendered_history_version:
            self._render_history()

    def _render_history(self) -> None:
        for widget in self.history_list.winfo_children():
            widget.destroy()

        if not self.model.history:
            ctk.CTkLabel(
                self.history_list, text="Nenhuma operação ainda.",
                text_color=Palette.MUTED,
            ).pack(pady=24)
        else:
            for entry in reversed(self.model.history[-50:]):
                text = (
                    f"{_shorten(prettify_expression(entry.expression), 30)}\n"
                    f"= {_shorten(entry.result, 26)}"
                )
                ctk.CTkButton(
                    self.history_list, text=text, anchor="e", height=54,
                    corner_radius=12, font=self.history_font,
                    fg_color=Palette.PANEL_ALT, hover_color=Palette.PANEL_ALT_HOVER,
                    text_color=Palette.TEXT,
                    command=partial(self._use_history_entry, entry),
                ).pack(fill="x", padx=2, pady=3)

        self._rendered_history_version = self.model.history_version


def main() -> int:
    if ctk is None:
        print("A biblioteca 'customtkinter' não está instalada.")
        print("Instale com:  pip install customtkinter")
        return 1
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")
    CalculatorApp().mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())