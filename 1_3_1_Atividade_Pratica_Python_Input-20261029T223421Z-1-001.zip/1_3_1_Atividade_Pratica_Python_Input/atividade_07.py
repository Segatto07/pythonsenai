nome = input("Digite seu nome: ")

idade = int(input("Digite sua idade: "))

peso = float(input("Digite seu peso: ").replace(",", "."))

print("Olá", nome, "você tem", idade, "anos e pesa", peso, "kg."),str(peso).replace(",", ".")

w