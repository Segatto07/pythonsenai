num1 = float(input("Digite o primeiro número: ").replace(",", "."))
num2 = float(input("Digite o segundo número: ").replace(",", "." ))

resultado = num1 ** num2

print("A potência de", num1, "elevado a", num2, "é = ", resultado)
